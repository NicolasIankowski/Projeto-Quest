<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

ini_set('session.use_strict_mode', '1');
session_set_cookie_params([
    'httponly' => true,
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'samesite' => 'Lax',
]);
session_start();

$resource = $_GET['resource'] ?? 'health';

function database(): PDO
{
    $host = getenv('DB_HOST') ?: '127.0.0.1';
    $database = getenv('DB_NAME') ?: 'projeto_quest';
    $username = getenv('DB_USER') ?: 'root';
    $password = getenv('DB_PASSWORD') ?: '';

    return new PDO(
        "mysql:host={$host};dbname={$database};charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
}

function respond(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function readInput(): array
{
    $input = json_decode(file_get_contents('php://input'), true);
    return is_array($input) ? $input : [];
}

function requireCsrf(): void
{
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        respond(['success' => false, 'message' => 'Sessão expirada. Atualize a página e tente novamente.'], 419);
    }
}

function requireUser(): int
{
    $userId = filter_var($_SESSION['user_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if ($userId === false) {
        respond(['success' => false, 'message' => 'Entre na sua conta para acessar este mapa.'], 401);
    }

    return $userId;
}

function startUserSession(array $user): array
{
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int) $user['id'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

    return [
        'id' => (int) $user['id'],
        'email' => $user['email'],
        'csrfToken' => $_SESSION['csrf_token'],
    ];
}

set_exception_handler(static function (Throwable $error): void {
    error_log($error->getMessage());
    respond([
        'success' => false,
        'message' => $error instanceof PDOException
            ? 'Não foi possível acessar o banco de dados. Confira a configuração e se o MySQL está iniciado.'
            : 'Ocorreu um erro interno na API.',
    ], $error instanceof PDOException ? 503 : 500);
});

function locationFromRow(array $row): array
{
    $row['lat'] = (float) $row['lat'];
    $row['lng'] = (float) $row['lng'];
    return $row;
}

if ($resource === 'health' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        database()->query('SELECT 1');
    } catch (Throwable $error) {
        respond([
            'success' => false,
            'service' => 'Projeto Quest API',
            'message' => 'Não foi possível conectar ao banco de dados.',
        ], 503);
    }

    respond([
        'success' => true,
        'service' => 'Projeto Quest API',
        'message' => 'A tripulação está a postos.',
        'database' => 'connected',
        'timestamp' => date(DATE_ATOM),
    ]);
}

if ($resource === 'auth' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $_SESSION['csrf_token'] ??= bin2hex(random_bytes(32));
    $userId = filter_var($_SESSION['user_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);

    respond([
        'success' => true,
        'authenticated' => $userId !== false,
        'user' => $userId !== false ? [
            'id' => $userId,
            'email' => $_SESSION['email'],
        ] : null,
        'csrfToken' => $_SESSION['csrf_token'],
    ]);
}

if ($resource === 'auth' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $input = readInput();
    $action = $input['action'] ?? '';
    $connection = database();

    if ($action === 'register') {
        $email = strtolower(trim((string) ($input['email'] ?? '')));
        $password = (string) ($input['password'] ?? '');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 254
            || strlen($password) < 8 || strlen($password) > 72) {
            respond(['success' => false, 'message' => 'Informe um e-mail válido e uma senha de 8 a 72 caracteres.'], 422);
        }

        $find = $connection->prepare('SELECT id FROM users WHERE email = :email');
        $find->execute(['email' => $email]);
        if ($find->fetch()) {
            respond(['success' => false, 'message' => 'Este e-mail já possui uma conta.'], 409);
        }

        $create = $connection->prepare('INSERT INTO users (email, password_hash) VALUES (:email, :password_hash)');
        $create->execute([
            'email' => $email,
            'password_hash' => password_hash($password, PASSWORD_DEFAULT),
        ]);
        $user = ['id' => (int) $connection->lastInsertId(), 'email' => $email];

        respond(['success' => true, 'user' => startUserSession($user)], 201);
    }

    if ($action === 'login') {
        $email = strtolower(trim((string) ($input['email'] ?? '')));
        $password = (string) ($input['password'] ?? '');
        $find = $connection->prepare('SELECT id, email, password_hash FROM users WHERE email = :email');
        $find->execute(['email' => $email]);
        $user = $find->fetch();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            respond(['success' => false, 'message' => 'E-mail ou senha incorretos.'], 401);
        }

        respond(['success' => true, 'user' => startUserSession($user)]);
    }

    if ($action === 'logout') {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $cookie = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires' => time() - 42000,
                'path' => $cookie['path'],
                'domain' => $cookie['domain'],
                'secure' => $cookie['secure'],
                'httponly' => $cookie['httponly'],
                'samesite' => $cookie['samesite'],
            ]);
        }
        session_destroy();
        respond(['success' => true]);
    }

    respond(['success' => false, 'message' => 'Ação de autenticação inválida.'], 400);
}

if ($resource === 'locations' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $userId = requireUser();
    $statement = database()->prepare(
        'SELECT id, name, type, `signal`, description, danger, reward, quest, npcs, lat, lng
         FROM locations WHERE user_id = :user_id ORDER BY id'
    );
    $statement->execute(['user_id' => $userId]);

    respond([
        'success' => true,
        'data' => array_map('locationFromRow', $statement->fetchAll()),
    ]);
}

if ($resource === 'locations' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $userId = requireUser();
    $input = readInput();
    $name = trim((string) ($input['name'] ?? ''));
    $type = trim((string) ($input['type'] ?? 'Waypoint'));
    $signal = trim((string) ($input['signal'] ?? 'Sinalizador'));
    $description = trim((string) ($input['description'] ?? 'Este local ainda não possui uma ficha detalhada.'));
    $danger = trim((string) ($input['danger'] ?? 'Baixo'));
    $reward = trim((string) ($input['reward'] ?? 'Sem recompensa definida'));
    $quest = trim((string) ($input['quest'] ?? 'Nenhuma missão registrada'));
    $npcs = trim((string) ($input['npcs'] ?? 'Nenhum NPC identificado'));
    $latitude = filter_var($input['lat'] ?? null, FILTER_VALIDATE_FLOAT);
    $longitude = filter_var($input['lng'] ?? null, FILTER_VALIDATE_FLOAT);

    if ($name === '' || $latitude === false || $longitude === false
        || $latitude < -90 || $latitude > 90 || $longitude < -180 || $longitude > 180) {
        respond([
            'success' => false,
            'message' => 'Envie name, lat e lng com valores válidos.',
        ], 422);
    }

    $connection = database();
    $location = [
        'user_id' => $userId,
        'name' => $name,
        'type' => $type === '' ? 'Waypoint' : $type,
        'signal' => $signal === '' ? 'Sinalizador' : $signal,
        'description' => $description === '' ? 'Este local ainda não possui uma ficha detalhada.' : $description,
        'danger' => $danger === '' ? 'Baixo' : $danger,
        'reward' => $reward === '' ? 'Sem recompensa definida' : $reward,
        'quest' => $quest === '' ? 'Nenhuma missão registrada' : $quest,
        'npcs' => $npcs === '' ? 'Nenhum NPC identificado' : $npcs,
        'lat' => (float) $latitude,
        'lng' => (float) $longitude,
    ];
    $statement = $connection->prepare(
        'INSERT INTO locations (user_id, name, type, `signal`, description, danger, reward, quest, npcs, lat, lng)
         VALUES (:user_id, :name, :type, :signal, :description, :danger, :reward, :quest, :npcs, :lat, :lng)'
    );
    $statement->execute($location);
    $location['id'] = (int) $connection->lastInsertId();
    unset($location['user_id']);

    respond(['success' => true, 'data' => $location], 201);
}

if ($resource === 'locations' && $_SERVER['REQUEST_METHOD'] === 'PUT') {
    requireCsrf();
    $userId = requireUser();
    $id = $_GET['id'] ?? null;
    $input = readInput();

    if ($id === null || $id === '') {
        respond(['success' => false, 'message' => 'ID do waypoint obrigatório.'], 400);
    }

    $id = filter_var($id, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if ($id === false) {
        respond(['success' => false, 'message' => 'ID do waypoint inválido.'], 400);
    }

    $connection = database();
    $find = $connection->prepare('SELECT * FROM locations WHERE id = :id AND user_id = :user_id');
    $find->execute(['id' => $id, 'user_id' => $userId]);
    $existing = $find->fetch();

    if (!$existing) {
        respond(['success' => false, 'message' => 'Waypoint não encontrado.'], 404);
    }

    $name = trim((string) ($input['name'] ?? $existing['name']));
    $type = trim((string) ($input['type'] ?? $existing['type']));
    $signal = trim((string) ($input['signal'] ?? $existing['signal']));
    $description = trim((string) ($input['description'] ?? $existing['description']));
    $danger = trim((string) ($input['danger'] ?? $existing['danger']));
    $reward = trim((string) ($input['reward'] ?? $existing['reward']));
    $quest = trim((string) ($input['quest'] ?? $existing['quest']));
    $npcs = trim((string) ($input['npcs'] ?? $existing['npcs']));
    $latitude = filter_var($input['lat'] ?? $existing['lat'], FILTER_VALIDATE_FLOAT);
    $longitude = filter_var($input['lng'] ?? $existing['lng'], FILTER_VALIDATE_FLOAT);

    if ($name === '' || $latitude === false || $longitude === false
        || $latitude < -90 || $latitude > 90 || $longitude < -180 || $longitude > 180) {
        respond(['success' => false, 'message' => 'Dados do waypoint inválidos.'], 422);
    }

    $location = [
        'id' => $id,
        'name' => $name,
        'type' => $type === '' ? 'Waypoint' : $type,
        'signal' => $signal === '' ? 'Sinalizador' : $signal,
        'description' => $description === '' ? 'Este local ainda não possui uma ficha detalhada.' : $description,
        'danger' => $danger === '' ? 'Baixo' : $danger,
        'reward' => $reward === '' ? 'Sem recompensa definida' : $reward,
        'quest' => $quest === '' ? 'Nenhuma missão registrada' : $quest,
        'npcs' => $npcs === '' ? 'Nenhum NPC identificado' : $npcs,
        'lat' => (float) $latitude,
        'lng' => (float) $longitude,
        'user_id' => $userId,
    ];
    $statement = $connection->prepare(
        'UPDATE locations SET name = :name, type = :type, `signal` = :signal,
         description = :description, danger = :danger, reward = :reward,
         quest = :quest, npcs = :npcs, lat = :lat, lng = :lng
         WHERE id = :id AND user_id = :user_id'
    );
    $statement->execute($location);
    unset($location['user_id']);

    respond(['success' => true, 'data' => $location], 200);
}

if ($resource === 'locations' && $_SERVER['REQUEST_METHOD'] === 'DELETE') {
    requireCsrf();
    $userId = requireUser();
    $id = $_GET['id'] ?? null;

    if ($id === null || $id === '') {
        respond(['success' => false, 'message' => 'ID do waypoint obrigatório.'], 400);
    }

    $id = filter_var($id, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if ($id === false) {
        respond(['success' => false, 'message' => 'ID do waypoint inválido.'], 400);
    }

    $statement = database()->prepare('DELETE FROM locations WHERE id = :id AND user_id = :user_id');
    $statement->execute(['id' => $id, 'user_id' => $userId]);

    if ($statement->rowCount() === 0) {
        respond(['success' => false, 'message' => 'Waypoint não encontrado.'], 404);
    }

    respond(['success' => true, 'data' => ['id' => $id]], 200);
}

respond(['success' => false, 'message' => 'Recurso ou método não encontrado.'], 404);
