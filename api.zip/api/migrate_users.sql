USE projeto_quest;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  email VARCHAR(254) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE locations
  ADD COLUMN IF NOT EXISTS user_id BIGINT UNSIGNED NULL AFTER id,
  ADD INDEX IF NOT EXISTS idx_locations_user_id (user_id);

ALTER TABLE locations
  ADD CONSTRAINT fk_locations_user
  FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE;