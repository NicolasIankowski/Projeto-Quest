import { $, api, setStatus } from './utils.js';
import { state } from './state.js';
import { loadLocations } from './waypoints.js';

let mode = 'login';

function showAccount(email) {
  $('accountEmail').textContent = email;
  $('accountControls').classList.remove('hidden');
  $('authPanel').classList.add('hidden');
}

export async function checkSession() {
  try {
    const result = await api('auth', { fallback: 'Falha ao verificar a conta.' });
    state.csrfToken = result.csrfToken;
    if (result.authenticated) {
      showAccount(result.user.email);
      loadLocations();
      return;
    }

    $('accountControls').classList.add('hidden');
    $('authPanel').classList.remove('hidden');
    setStatus('Entre ou crie uma conta para abrir seu mapa.');
  } catch (error) {
    setStatus(error.message || 'Não foi possível verificar sua sessão.');
    console.error(error);
  }
}

function setAuthMode(next) {
  mode = next;
  const registering = mode === 'register';
  $('authTitle').textContent = registering ? 'Criar sua conta' : 'Entre na sua carta';
  $('authDescription').textContent = registering
    ? 'Sua carta e seus waypoints ficarão associados a esta conta.'
    : 'Acesse seus waypoints salvos.';
  $('authSubmit').textContent = registering ? 'Criar conta' : 'Entrar';
  $('authSwitch').textContent = registering ? 'Já tenho uma conta' : 'Criar uma conta';
  $('authPassword').setAttribute('autocomplete', registering ? 'new-password' : 'current-password');
  $('authMessage').textContent = '';
}

async function submitAuth(event) {
  event.preventDefault();
  const form = event.currentTarget; // event.currentTarget vira null após o primeiro await
  const data = new FormData(form);
  $('authSubmit').disabled = true;
  $('authMessage').textContent = '';

  try {
    const { user } = await api('auth', {
      method: 'POST',
      fallback: 'Não foi possível acessar a conta.',
      body: {
        action: mode === 'register' ? 'register' : 'login',
        email: String(data.get('email') || '').trim(),
        password: String(data.get('password') || '')
      }
    });

    state.csrfToken = user.csrfToken;
    showAccount(user.email);
    form.reset();
    setStatus(`Carta carregada para ${user.email}.`);
    loadLocations();
  } catch (error) {
    $('authMessage').textContent = error.message || 'Não foi possível acessar a conta.';
  } finally {
    $('authSubmit').disabled = false;
  }
}

async function logout() {
  try {
    await api('auth', { method: 'POST', body: { action: 'logout' }, fallback: 'Não foi possível encerrar a sessão.' });
    window.location.reload();
  } catch (error) {
    setStatus(error.message || 'Não foi possível encerrar a sessão.');
  }
}

export function bindAuth() {
  $('authForm').addEventListener('submit', submitAuth);
  $('authSwitch').addEventListener('click', () => setAuthMode(mode === 'login' ? 'register' : 'login'));
  $('logoutButton').addEventListener('click', logout);
}
