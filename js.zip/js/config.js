// Configurações e dados estáticos do mapa.
export const MAPS_API_KEY = 'AIzaSyDRrqdnjnfHdqngc_CkBgSJmpquGAFyKNY';
export const DEFAULT_POSITION = { lat: -26.4852, lng: -49.0714 };

// Opções dos <select> (antes escritas à mão no HTML).
export const WAYPOINT_OPTIONS = {
  type: ['Parque', 'Igreja', 'Centro', 'Rodoviária', 'Ruína', 'Portal', 'Criatura', 'Sinalizador'],
  signal: ['Bandeira', 'Tocha', 'Farol', 'Pilar', 'Marca', 'Portal', 'Escudo'],
  danger: ['Inofensivo', 'Baixo', 'Médio', 'Alto', 'Mortal']
};
export const ROUTE_MODES = [['DRIVING', 'Carro'], ['WALKING', 'A pé'], ['BICYCLING', 'Bicicleta'], ['TRANSIT', 'Transporte público']];

// [featureType, elementType, cor, espessura?]
export const MAP_STYLES = [
  ['', 'geometry', '#d8c59a'],
  ['', 'labels.text.fill', '#3d3326'],
  ['', 'labels.text.stroke', '#ead9ad'],
  ['administrative', 'geometry.stroke', '#8a6b3d'],
  ['administrative.country', 'geometry.stroke', '#5f482b', 1.5],
  ['landscape.natural', 'geometry', '#c9b27d'],
  ['poi', 'geometry', '#b99d68'],
  ['poi.park', 'geometry', '#9eae78'],
  ['road', 'geometry', '#a47e4b'],
  ['road', 'geometry.stroke', '#765731'],
  ['road', 'labels.text.fill', '#4b3927'],
  ['transit', 'geometry', '#947348'],
  ['water', 'geometry', '#427b83'],
  ['water', 'labels.text.fill', '#d5e1ce']
].map(([featureType, elementType, color, weight]) => ({
  ...(featureType && { featureType }),
  elementType,
  stylers: [{ color }, ...(weight ? [{ weight }] : [])]
}));
