// Categorias de waypoint: uma única tabela substitui as quatro cadeias de "if".
// keys  -> palavras que classificam o tipo, o ícone e o emoji
// fkeys -> palavras (mais restritas) usadas na ficha do balão de informações
const CATEGORIES = [
  { keys: ['parque', 'bosque', 'natureza', 'floresta'],  fkeys: ['parque'],                    type: 'Refúgio da natureza', label: 'Bosque sagrado',    emoji: '🌿',  tag: 'NAT',  color: '#285f3d', glow: '#dff8e3', aura: '#66b975' },
  { keys: ['igreja', 'templo', 'capela', 'santuário'],   fkeys: ['igreja', 'templo'],          type: 'Estrutura sagrada',   label: 'Templo antigo',     emoji: '⛪',  tag: 'SAGR', color: '#8a5b2f', glow: '#f6e7d0', aura: '#c9924d' },
  { keys: ['rodovi', 'estação', 'terminal', 'trilhos'],  fkeys: ['rodovi', 'estação'],         type: 'Ponto de passagem',   label: 'Estação de viagem', emoji: '🛤️', tag: 'TRAV', color: '#996535', glow: '#f9e0b4', aura: '#a87335' },
  { keys: ['centro', 'praça', 'mercado', 'cidade'],      fkeys: ['centro', 'praça'],           type: 'Marca do povoado',    label: 'Povoado central',   emoji: '🏛️', tag: 'POVO', color: '#5e4ca3', glow: '#e5dcff', aura: '#785bc0' },
  { keys: ['porto', 'mar', 'rio', 'lago'],               fkeys: ['porto', 'rio', 'mar'],       type: 'Rota aquática',       label: 'Rota marítima',     emoji: '⚓',  tag: 'MAR',  color: '#316c9b', glow: '#d9ebff', aura: '#3d8cb2' },
  { keys: ['ruína', 'museu', 'antiga', 'castelo'],       fkeys: ['ruína', 'castelo'],          type: 'Relíquia antiga',     label: 'Ruína antiga',      emoji: '🗿',  tag: 'ANT',  color: '#727b82', glow: '#eef0f5', aura: '#7b7d87' },
  { keys: ['criatura', 'monstro', 'selva', 'caverna'],   fkeys: ['criatura', 'monstro', 'caverna'], type: 'Ameaça ou criatura', label: 'Criatura perigosa', emoji: '🐲', tag: 'PERI', color: '#8d2f2f', glow: '#ffd9d9', aura: '#bf4a4a' }
];

const FALLBACK = { type: 'Waypoint misterioso', label: 'Portal misterioso', emoji: '✨', tag: 'MIST', color: '#bf7c2d', glow: '#fff0c6', aura: '#d6952b' };

export function findCategory(name, field = 'keys') {
  const text = (name || '').toLowerCase();
  return CATEGORIES.find((category) => category[field].some((key) => text.includes(key))) || FALLBACK;
}

export function createWaypointIcon(symbol, color, accent, detail = '') {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="64" height="74" viewBox="0 0 64 74">
<defs>
<radialGradient id="glow" cx="50%" cy="35%" r="60%"><stop offset="0%" stop-color="${accent}" stop-opacity="1"/><stop offset="100%" stop-color="${accent}" stop-opacity="0.1"/></radialGradient>
<filter id="shadow" x="-20%" y="-20%" width="140%" height="160%"><feDropShadow dx="0" dy="4" stdDeviation="2.5" flood-color="rgba(0,0,0,0.45)"/></filter>
</defs>
<circle cx="32" cy="26" r="22" fill="url(#glow)"/>
<path d="M32 2C19.3 2 9 12.3 9 25c0 12.7 11.9 24.6 23 41.7C45.1 49.6 57 37.7 57 25 57 12.3 46.7 2 32 2Z" fill="${color}" filter="url(#shadow)"/>
<path d="M32 9.5c-9.2 0-16.7 7.5-16.7 16.8 0 8.7 8.5 17.2 16.7 28.5 8.2-11.3 16.7-19.8 16.7-28.5C48.7 17 41.2 9.5 32 9.5Z" fill="${accent}" opacity="0.25"/>
<text x="32" y="32" font-size="18" text-anchor="middle" dominant-baseline="middle" font-family="Segoe UI Emoji, Arial">${symbol}</text>
<text x="32" y="61" font-size="8" text-anchor="middle" font-family="Segoe UI, Arial" fill="#fff8ef" style="font-weight:700; letter-spacing:1px;">${detail}</text>
</svg>`;

  return {
    url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svg),
    scaledSize: new google.maps.Size(52, 64),
    anchor: new google.maps.Point(26, 64)
  };
}

export function getWaypointIcon(name) {
  const { emoji, color, glow, tag } = findCategory(name);
  return createWaypointIcon(emoji, color, glow, tag);
}
