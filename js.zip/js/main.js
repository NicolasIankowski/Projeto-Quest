import { $, setStatus } from './utils.js';
import { initPanels } from './panels.js';
import { bindAuth, checkSession } from './auth.js';
import { clearRoute, bindRoutes } from './routes.js';
import { bindSearch, setupPlaceAutocomplete } from './search.js';
import { bindWaypoints, disableClickMode, startNewWaypoint } from './waypoints.js';
import { createMap, loadMapsApi, locateUser } from './map.js';

initPanels({
  search:   { show: () => $('mapSearchInput').focus() },
  waypoint: { open: startNewWaypoint, userClose: disableClickMode },
  routes:   { show: () => $('routeOrigin').focus(), hide: clearRoute }
});

bindWaypoints();
bindSearch();
bindAuth();
bindRoutes();
$('locateButton').addEventListener('click', locateUser);

loadMapsApi(() => {
  createMap();
  setupPlaceAutocomplete();
  setStatus('A carta está pronta. Você está navegando por Jaraguá do Sul.');
  checkSession();
});
