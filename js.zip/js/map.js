import { $, el, geolocate, setStatus } from './utils.js';
import { state } from './state.js';
import { DEFAULT_POSITION, MAP_STYLES, MAPS_API_KEY } from './config.js';
import { applyMapClick } from './waypoints.js';

export function createMap() {
  state.map = new google.maps.Map($('map'), {
    center: DEFAULT_POSITION,
    zoom: 12,
    mapTypeControl: false,
    streetViewControl: false,
    fullscreenControl: true,
    styles: MAP_STYLES
  });
  state.map.addListener('click', ({ latLng }) => {
    if (state.clickMode) applyMapClick(latLng.lat(), latLng.lng());
  });
}

// Carrega a API do Google Maps (antes uma <script> no fim do HTML).
export function loadMapsApi(onReady) {
  window.initMap = onReady;
  document.head.append(el('script', {
    async: true,
    src: `https://maps.googleapis.com/maps/api/js?key=${MAPS_API_KEY}&callback=initMap&libraries=places&v=weekly`,
    onerror: () => {
      setStatus('O mapa não carregou. Confirme a chave, o faturamento e a Maps JavaScript API no Google Cloud.');
      $('locateButton').disabled = true;
    }
  }));
}

export function locateUser() {
  if (!state.map) return setStatus('Aguarde o mapa terminar de carregar.');

  const button = $('locateButton');
  geolocate({
    say: setStatus,
    begin: () => {
      button.disabled = true;
      setStatus('Solicitando sua localização...');
    },
    found: (position) => {
      state.map.setCenter(position);
      state.map.setZoom(15);
      state.userMarker?.setMap(null);
      state.userMarker = new google.maps.Marker({
        position,
        map: state.map,
        title: 'Minha localização',
        animation: google.maps.Animation.DROP
      });
      setStatus('Sua localização foi encontrada.');
    },
    done: () => { button.disabled = false; }
  });
}
