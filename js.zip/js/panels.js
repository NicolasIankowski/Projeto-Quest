import { $, el } from './utils.js';

// Painéis da carta: cada um tem botão de ferramenta, botão de fechar e
// a lista de painéis que ele fecha ao abrir.
const PANELS = {
  search:   { el: 'mapSearch',     btn: 'toggleSearch',   close: 'closeSearch',        icon: '⌕', label: 'Abrir pesquisa',   title: 'Pesquisar local',   others: ['routes'] },
  waypoint: { el: 'waypointPanel', btn: 'toggleWaypoint', close: 'closeWaypointPanel', icon: '⚑', label: 'Abrir waypoints',  title: 'Criar waypoint',     others: ['routes'] },
  routes:   { el: 'routePanel',    btn: 'toggleRoutes',   close: 'closeRoutes',        icon: '↝', label: 'Abrir rotas',      title: 'Planejar uma rota',  others: ['search', 'waypoint'] }
};

const hooks = {};

export function setPanel(name, show) {
  $(PANELS[name].el).classList.toggle('hidden', !show);
  $(PANELS[name].btn).setAttribute('aria-expanded', String(show));
  hooks[name]?.[show ? 'show' : 'hide']?.();
}

// hooks: { painel: { show, hide, open, userClose } }
//  show/hide: rodam sempre que o painel abre/fecha
//  open: substitui a abertura simples quando o usuário clica no botão da ferramenta
//  userClose: roda quando o usuário fecha o painel pelos botões
export function initPanels(panelHooks) {
  Object.assign(hooks, panelHooks);

  $('mapTools').append(...Object.values(PANELS).map((panel) => {
    const button = el('button', { id: panel.btn, type: 'button', className: 'tool-button', title: panel.title, textContent: panel.icon });
    button.setAttribute('aria-label', panel.label);
    button.setAttribute('aria-expanded', 'false');
    return button;
  }));

  for (const [name, panel] of Object.entries(PANELS)) {
    $(panel.btn).addEventListener('click', () => {
      const opening = $(panel.el).classList.contains('hidden');
      if (opening) panel.others.forEach((other) => setPanel(other, false));
      else hooks[name]?.userClose?.();

      if (opening && hooks[name]?.open) hooks[name].open();
      else setPanel(name, opening);
    });

    $(panel.close).addEventListener('click', () => {
      setPanel(name, false);
      hooks[name]?.userClose?.();
    });
  }
}
