import { $, el, fillSelect, geolocate } from './utils.js';
import { state } from './state.js';
import { ROUTE_MODES } from './config.js';

let lines = [];
let requestId = 0;
let originCoords = null;

const say = (text) => { $('routeStatus').textContent = text; };

export function clearRoute() {
  requestId += 1;
  $('calculateRoute').disabled = false;
  lines.forEach((line) => line.setMap(null));
  lines = [];
  $('routeResults').classList.add('hidden');
  $('routeSummary').replaceChildren();
  $('routeSteps').replaceChildren();
  say('');
}

async function calculateRoute(event) {
  event.preventDefault();
  const originLabel = $('routeOrigin').value.trim();
  const origin = originCoords && originLabel === 'Minha localização' ? originCoords : originLabel;
  const destination = $('routeDestination').value.trim();
  if (!origin || !destination) return;

  clearRoute();
  const current = requestId;
  const button = $('calculateRoute');
  button.disabled = true;
  say('Calculando o melhor caminho...');

  try {
    const { Route } = await google.maps.importLibrary('routes');
    const { routes = [] } = await Route.computeRoutes({
      origin,
      destination,
      travelMode: $('routeMode').value,
      language: 'pt-BR',
      region: 'BR',
      fields: ['path', 'viewport', 'durationMillis', 'distanceMeters', 'localizedValues', 'legs.steps.instructions', 'legs.steps.distanceMeters', 'legs.steps.localizedValues']
    });

    if (current !== requestId) return;
    const route = routes[0];
    if (!route) return say('Nenhuma rota encontrada para esses locais e meio de transporte.');

    lines = route.createPolylines({ polylineOptions: { strokeColor: '#c05034', strokeWeight: 6, strokeOpacity: 0.88 } });
    lines.forEach((line) => line.setMap(state.map));
    if (route.viewport) state.map.fitBounds(route.viewport);

    const distance = route.localizedValues?.distance || `${(route.distanceMeters / 1000).toFixed(1)} km`;
    const duration = route.localizedValues?.duration || 'Duração indisponível';
    $('routeSummary').append(
      el('strong', { textContent: `${distance} · ${duration}` }),
      el('span', { textContent: `${originLabel} → ${destination}` })
    );

    (route.legs || []).flatMap((leg) => leg.steps || []).forEach((step) => {
      const stepDistance = step.localizedValues?.distance;
      $('routeSteps').append(el('li', {},
        el('span', { textContent: step.instructions || 'Continue pela rota.' }),
        ...(stepDistance ? [el('small', { textContent: stepDistance })] : [])
      ));
    });
    $('routeResults').classList.remove('hidden');
    say('');
  } catch (error) {
    if (current !== requestId) return;
    console.error('Falha ao calcular rota:', error);
    say('Não foi possível calcular. Confira se a Routes API está habilitada e tente locais mais específicos.');
  } finally {
    if (current === requestId) button.disabled = false;
  }
}

export function bindRoutes() {
  fillSelect($('routeMode'), ROUTE_MODES);
  $('routeForm').addEventListener('submit', calculateRoute);
  $('routeOrigin').addEventListener('input', () => { originCoords = null; });
  $('clearRoute').addEventListener('click', () => {
    clearRoute();
    $('routeForm').reset();
    originCoords = null;
  });
  $('useCurrentPosition').addEventListener('click', () => geolocate({
    say,
    begin: () => say('Localizando sua posição...'),
    found: (position) => {
      originCoords = position;
      $('routeOrigin').value = 'Minha localização';
      say('');
    }
  }));
}
