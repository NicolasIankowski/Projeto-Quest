import { $, setStatus } from './utils.js';
import { state } from './state.js';
import { createWaypointIcon } from './icons.js';

const say = (text) => { $('searchMessage').textContent = text; };
const SEARCH_FIELDS = ['name', 'type', 'description', 'quest', 'npcs', 'signal'];

const normalize = (value) => String(value || '')
  .normalize('NFD')
  .replace(/[\u0300-\u036f]/g, '')
  .toLocaleLowerCase('pt-BR')
  .trim();

export async function setupPlaceAutocomplete() {
  try {
    const { PlaceAutocompleteElement } = await google.maps.importLibrary('places');
    const autocomplete = new PlaceAutocompleteElement({
      placeholder: 'Digite uma rua, cidade, país ou local...',
      description: 'Sugestões do Google Maps',
      requestedLanguage: 'pt-BR',
      requestedRegion: 'br',
      locationBias: state.map.getBounds()
    });
    autocomplete.id = 'mapSearchInput';
    autocomplete.setAttribute('aria-label', 'Pesquisar rua, cidade, país ou waypoint');
    $('mapSearchInput').replaceWith(autocomplete);

    state.map.addListener('bounds_changed', () => { autocomplete.locationBias = state.map.getBounds(); });

    autocomplete.addEventListener('gmp-select', async ({ placePrediction }) => {
      try {
        const place = placePrediction.toPlace();
        await place.fetchFields({ fields: ['displayName', 'formattedAddress', 'location', 'viewport'] });
        focusSearchResult(place);
      } catch (error) {
        console.error('Falha ao carregar o local selecionado:', error);
        say('Não foi possível carregar esse local. Tente pesquisar pelo botão.');
      }
    });

    autocomplete.addEventListener('gmp-error', () => {
      say('O Google recusou as sugestões. Confira se a Places API (New) está habilitada.');
    });
    say('Sugestões do Google e waypoints da carta.');
  } catch (error) {
    console.error('Autocomplete indisponível:', error);
    say('Sugestões indisponíveis. Ainda é possível pesquisar pelo botão.');
  }
}

function focusSearchResult(result) {
  const position = result.location || result.geometry?.location;
  const viewport = result.viewport || result.geometry?.viewport;
  const label = result.formattedAddress || result.formatted_address || result.displayName || result.name || 'Local selecionado';
  if (!position) return false;

  state.searchMarker?.setMap(null);
  state.searchMarker = new google.maps.Marker({
    position,
    map: state.map,
    title: label,
    icon: createWaypointIcon('⌕', '#244f59', '#c9e0dd', 'BUSCA'),
    animation: google.maps.Animation.DROP
  });

  if (viewport) {
    state.map.fitBounds(viewport);
  } else {
    state.map.setCenter(position);
    state.map.setZoom(16);
  }

  say(label);
  setStatus(`Local encontrado: ${label}`);
  return true;
}

function findWaypoint(query) {
  const needle = normalize(query);
  if (!needle) return null;

  const rank = ({ location }) => {
    const name = normalize(location.name);
    return name === needle ? 0 : name.startsWith(needle) ? 1 : 2;
  };

  return state.waypoints
    .map((location, index) => ({ location, index }))
    .filter(({ location }) => SEARCH_FIELDS.some((field) => normalize(location[field]).includes(needle)))
    .sort((a, b) => rank(a) - rank(b))[0] || null;
}

function focusWaypointResult({ location, index }) {
  const position = { lat: Number(location.lat), lng: Number(location.lng) };
  if (!Number.isFinite(position.lat) || !Number.isFinite(position.lng)) return false;

  state.searchMarker?.setMap(null);
  state.searchMarker = null;

  state.map.panTo(position);
  state.map.setZoom(16);
  if (state.markers[index]) google.maps.event.trigger(state.markers[index], 'click');
  say(`Waypoint encontrado: ${location.name}`);
  setStatus(`Waypoint localizado: ${location.name}`);
  return true;
}

async function searchMapLocation(event) {
  event.preventDefault();
  const input = $('mapSearchInput');
  const query = input.value.trim();

  if (!query) {
    say('Digite uma rua, cidade ou ponto de referência.');
    input.focus();
    return;
  }
  if (!state.map) return say('Aguarde a carta terminar de carregar.');

  const waypointMatch = findWaypoint(query);
  if (waypointMatch && focusWaypointResult(waypointMatch)) return;

  const Place = google.maps.places?.Place;
  if (!Place?.searchByText) return say('Busca de lugares indisponível. Ative a Places API (New) no Google Cloud.');

  say('Pesquisando ruas, cidades e países...');
  try {
    const { places = [] } = await Place.searchByText({
      textQuery: query,
      fields: ['displayName', 'formattedAddress', 'location', 'viewport'],
      language: 'pt-BR',
      maxResultCount: 1
    });

    if (!places.length || !focusSearchResult(places[0])) {
      say('Nenhum local encontrado. Confira a grafia ou tente incluir a cidade.');
      setStatus(`Não foi possível localizar “${query}”.`);
    }
  } catch (error) {
    console.error('Falha na pesquisa de lugares:', error);
    say('O Google recusou a busca. Ative a Places API (New) e o faturamento no projeto da chave.');
    setStatus('A busca geográfica não foi autorizada pelo Google Maps.');
  }
}

export function bindSearch() {
  $('mapSearch').addEventListener('submit', searchMapLocation);
}
