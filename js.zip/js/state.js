// Estado compartilhado entre os módulos.
export const state = {
  map: null,
  userMarker: null,
  searchMarker: null,
  markers: [],
  waypoints: [],
  infoWindow: null,
  clickMode: false,
  csrfToken: null
};
