import { state } from './state.js';

export const $ = (id) => document.getElementById(id);
export const setStatus = (message) => { $('status').textContent = message; };

// Cria um elemento: el('li', { className: 'x' }, filho1, filho2)
export function el(tag, props = {}, ...children) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

// Preenche um <select> com strings ou pares [valor, rótulo].
export const fillSelect = (select, items) =>
  select.replaceChildren(...items.map((item) => (Array.isArray(item) ? new Option(item[1], item[0]) : new Option(item))));

const ESCAPES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ESCAPES[char]);

// Chamada única à API PHP: monta a URL, envia o token CSRF e valida a resposta.
export async function api(resource, { method = 'GET', id, body, fallback = 'Falha ao acessar a API.' } = {}) {
  const headers = {};
  if (body) headers['Content-Type'] = 'application/json';
  if (method !== 'GET') headers['X-CSRF-Token'] = state.csrfToken;

  const url = `api/index.php?resource=${resource}${id ? `&id=${encodeURIComponent(id)}` : ''}`;
  const response = await fetch(url, { method, headers, body: body && JSON.stringify(body) });
  const result = await response.json().catch(() => {
    throw new Error('A API PHP não retornou JSON. Inicie o servidor PHP pela pasta do projeto.');
  });
  if (!response.ok || !result.success) throw new Error(result.message || fallback);
  return result;
}

// Geolocalização compartilhada pelo botão da bússola e pela ferramenta de rotas.
export function geolocate({ say, begin, found, done }) {
  if (!navigator.geolocation) return say('Seu navegador não oferece geolocalização.');
  begin?.();
  navigator.geolocation.getCurrentPosition(
    ({ coords }) => { found({ lat: coords.latitude, lng: coords.longitude }); done?.(); },
    () => { say('Não foi possível acessar sua localização. Verifique a permissão do navegador.'); done?.(); },
    { enableHighAccuracy: true, timeout: 10000 }
  );
}
