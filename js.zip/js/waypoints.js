import { $, api, el, escapeHtml, fillSelect, setStatus } from './utils.js';
import { state } from './state.js';
import { setPanel } from './panels.js';
import { WAYPOINT_OPTIONS } from './config.js';
import { findCategory, getWaypointIcon } from './icons.js';

const LOCATIONS = 'locations';
const FORM_DEFAULTS = { type: 'Parque', signal: 'Bandeira', danger: 'Baixo' };
const form = () => $('waypointForm');

// ---------- Balão de informações do marcador ----------
function infoWindowContent(location) {
  const { glow, aura, emoji } = findCategory(location.type || location.name, 'fkeys');
  const type = location.type || findCategory(location.name).type;
  const [signal, danger, reward, quest, npcs, description] = [
    location.signal || 'Sinalizador',
    location.danger || 'Baixo',
    location.reward || 'Sem recompensa definida',
    location.quest || 'Nenhuma missão registrada',
    location.npcs || 'Nenhum NPC identificado',
    location.description || 'Este local ainda não possui uma ficha detalhada.'
  ].map(escapeHtml);

  const content = el('div');
  content.innerHTML = `
    <div class="iw" style="--glow:${glow}; --aura:${aura}">
      <div class="iw-head"><span class="iw-sprite">${emoji}</span><strong>${escapeHtml(location.name)}</strong></div>
      <div class="iw-tags">
        <div><strong>Tipo:</strong> ${escapeHtml(type)}</div>
        <div><strong>Sinalizador:</strong> ${signal}</div>
        <div><strong>Perigo:</strong> ${danger}</div>
      </div>
      <div class="iw-sheet">
        <strong>Ficha do local:</strong><br>${description}<br><br>
        <strong>Recompensa:</strong> ${reward}<br>
        <strong>Quest:</strong> ${quest}<br>
        <strong>NPCs:</strong> ${npcs}
      </div>
      <div class="iw-actions">
        <button type="button" class="mini-action-button" data-action="edit">Editar</button>
        <button type="button" class="mini-action-button danger" data-action="delete">Remover</button>
      </div>
    </div>`;

  content.addEventListener('click', (event) => {
    const action = event.target.closest('[data-action]')?.dataset.action;
    if (!action) return;
    state.infoWindow.close();
    if (action === 'edit') fillWaypointForm(location);
    else deleteWaypoint(location.id, location.name);
  });
  return content;
}

function createMarker(location) {
  const marker = new google.maps.Marker({
    position: { lat: location.lat, lng: location.lng },
    map: state.map,
    title: location.name,
    icon: getWaypointIcon(location.type || location.name || 'Waypoint'),
    animation: google.maps.Animation.DROP
  });

  marker.addListener('click', () => {
    state.infoWindow?.close();
    state.infoWindow = new google.maps.InfoWindow({ content: infoWindowContent(location) });
    state.infoWindow.open({ map: state.map, anchor: marker });
  });
  return marker;
}

export async function loadLocations() {
  try {
    const result = await api(LOCATIONS);
    state.waypoints = Array.isArray(result.data) ? result.data : [];
    $('waypointSuggestions').replaceChildren(...state.waypoints.map(({ name }) => el('option', { value: name })));
    state.markers.forEach((marker) => marker.setMap(null));
    state.markers = state.waypoints.map(createMarker);
    setStatus(`${state.markers.length} waypoint(s) descoberto(s) na carta.`);
  } catch (error) {
    setStatus('A carta abriu, mas a API PHP não respondeu. Inicie o servidor PHP para carregar os locais.');
    console.error(error);
  }
}

// ---------- Formulário ----------
function setCoordinates(lat, lng) {
  form().elements.lat.value = Number(lat).toFixed(6);
  form().elements.lng.value = Number(lng).toFixed(6);
}

function setClickMode(active) {
  state.clickMode = active;
  $('clickMapWaypoint').textContent = active ? 'Clique no mapa ativo' : 'Clique no mapa';
  $('clickMapWaypoint').classList.toggle('active', active);
  if (active) setStatus('Modo de criação: clique no mapa para posicionar o waypoint.');
}
export const disableClickMode = () => setClickMode(false);

export function applyMapClick(lat, lng) {
  setCoordinates(lat, lng);
  setStatus('Coordenadas definidas pelo clique no mapa.');
  disableClickMode();
}

function useMapCenter() {
  if (!state.map) return;
  const center = state.map.getCenter();
  setCoordinates(center.lat(), center.lng());
}

function fillWaypointForm(location) {
  form().reset();
  for (const field of form().elements) {
    if (!field.name) continue;
    const isCoordinate = field.name === 'lat' || field.name === 'lng';
    field.value = isCoordinate ? location[field.name] ?? '' : location[field.name] || FORM_DEFAULTS[field.name] || '';
  }
  $('waypointPanelTitle').textContent = location.id ? 'Editar waypoint' : 'Novo waypoint';
  setPanel('waypoint', true);
}

export function startNewWaypoint() {
  fillWaypointForm({});
  useMapCenter();
  setClickMode(true);
}

// ---------- Salvar e remover ----------
async function saveWaypoint(event) {
  event.preventDefault();
  const data = new FormData(form());
  const text = (key) => String(data.get(key) || '').trim();
  const id = text('id');
  const payload = {
    name: text('name'),
    type: String(data.get('type') || 'Sinalizador'),
    signal: String(data.get('signal') || 'Bandeira'),
    description: text('description'),
    danger: String(data.get('danger') || 'Baixo'),
    reward: text('reward'),
    quest: text('quest'),
    npcs: text('npcs'),
    lat: Number(data.get('lat')),
    lng: Number(data.get('lng'))
  };

  if (!payload.name) return setStatus('Dê um nome para o waypoint antes de salvar.');

  if (!Number.isFinite(payload.lat) || !Number.isFinite(payload.lng)) {
    const center = state.map.getCenter();
    payload.lat = center.lat();
    payload.lng = center.lng();
  }

  try {
    await api(LOCATIONS, { method: id ? 'PUT' : 'POST', id, body: payload, fallback: 'Falha ao salvar waypoint' });
    form().reset();
    setPanel('waypoint', false);
    setStatus(id ? `Waypoint "${payload.name}" foi atualizado.` : `Waypoint "${payload.name}" foi criado com sucesso.`);
    loadLocations();
  } catch (error) {
    setStatus(error.name === 'TypeError'
      ? 'Não foi possível acessar a API. Abra o mapa em http://localhost:8000/MapFront.html com o servidor PHP ativo.'
      : error.message || 'Não foi possível salvar o waypoint.');
    console.error(error);
  }
}

async function deleteWaypoint(id, name) {
  if (!window.confirm(`Deseja remover "${name}" do mapa?`)) return;

  try {
    await api(LOCATIONS, { method: 'DELETE', id, fallback: 'Falha ao remover waypoint' });
    state.infoWindow?.close();
    setStatus(`Waypoint "${name}" foi removido.`);
    loadLocations();
  } catch (error) {
    setStatus(error.message || 'Não foi possível remover o waypoint.');
    console.error(error);
  }
}

export function bindWaypoints() {
  for (const [name, options] of Object.entries(WAYPOINT_OPTIONS)) fillSelect(form().elements[name], options);
  form().addEventListener('submit', saveWaypoint);
  $('useMapCenter').addEventListener('click', useMapCenter);
  $('clickMapWaypoint').addEventListener('click', () => {
    setPanel('waypoint', true);
    setClickMode(true);
  });
}
